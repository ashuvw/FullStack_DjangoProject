# django-like-add-to-favorites-buttton
a simple Django Project with like or add to favorites button
